<?php
require("soporte.php");
$auth->logout();
header("Location:inicio.php");exit;

?>
